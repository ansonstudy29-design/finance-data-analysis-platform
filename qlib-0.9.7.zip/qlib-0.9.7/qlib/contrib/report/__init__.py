# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

GRAPH_NAME_LIST = [
    "analysis_position.report_graph",
    "analysis_position.score_ic_graph",
    "analysis_position.cumulative_return_graph",
    "analysis_position.risk_analysis_graph",
    "analysis_position.rank_label_graph",
    "analysis_model.model_performance_graph",
]
