# Requirements

Here is the minimal hardware requirements to run the `workflow_by_code` example.
- Memory: 16G
- Free Disk: 5G


# NOTE
The results will slightly vary on different OSs(the variance of annualized return will be less than 2%).
The evaluation results in the `README.md` page are from Linux OS.
